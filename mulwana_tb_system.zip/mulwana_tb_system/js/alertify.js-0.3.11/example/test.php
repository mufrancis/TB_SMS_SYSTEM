<link rel="stylesheet" href="../themes/alertify.core.css" />
<link rel="stylesheet" href="../themes/alertify.default.css" id="toggleCSS" />
<script src="assets/js/lib/sh/jquery-2.0.3.min.js"></script>
<script src="../lib/alertify.min.js"></script>





<button id="test1"> test1</button>
<button id="test2"> test12</button>

<script>
	$("#test1").on('click', function() {
		//		reset();
		alertify.alert("This is an alert dialog");
		return false;
	});

	$("#test2").on('click', function() {
		//		reset();
		alertify.prompt("This is a prompt dialog", function(e, str) {
			if (e) {
				alertify.success("You've clicked OK and typed: " + str);
			} else {
				alertify.error("You've clicked Cancel");
			}
		}, "Default Value");
		return false;
	});

</script>
