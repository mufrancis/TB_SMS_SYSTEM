<?php  session_start();ob_start();
// include("../query/functions.php");
        
            
            $_SESSION = array();
            
            // 3. Destroy the session cookie
            if(isset($_COOKIE[session_name()])) {
                  setcookie(session_name(), '', time()-420000);
            session_destroy();
            session_destroy();
            header('location:login.php?logout=1');
            }
            
            // 4. Destroy the session
                
    echo "PLEASE BAD PAGE/S REQUEST !  note after login out you cant go back to any page";
//     sleep(10);
//     direct('../login.php?logout=1')
?>