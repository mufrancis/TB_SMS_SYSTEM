
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup - Dark Admin</title>

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/local.css" />

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>   
</head>
<body>
        <div id="page-wrapper">
<?php
session_start();
include_once('./connection/connect.php');

include_once("query/function.php");
if(isset($_REQUEST['login_'])){
    login($link_connector);
}

?>
            <div class="row">
<!-- <div class='panel'> -->
                <div class="col-lg-6 col-lg-offset-3 text-center v-center  panel">

                    <h1>Sign Up</h1>
                    <p class="lead">Enter your Email and Password to join T.B system  </p>

                    <!-- <iframe allowpaymentrequest allow=’usb fullscreen’></iframe> -->





                    <br>
                   

                    <form class="col-lg-12">
                        <div class="input-group col-lg-10" style=" text-align: center; margin: 0 auto;">
                            <span class="input-group-btn">
                                <button class="btn btn-lg btn-primary " type="button">
                                    <i class="fa fa-user"></i>
                                </button></span>
                            <input class="form-control input-lg" name="Email" title="Confidential signup."
                                placeholder="Enter your email" type="text">
                        </div>
                        <br>
                        <div class="input-group col-lg-10" style=" text-align: center; margin: 0 auto;">
                            <input class="form-control input-lg" name="password" type='password' title="Confidential signup."
                                placeholder="Enter your password" type="text">
                            <span class="input-group-btn">
                                <button class="btn btn-lg btn-primary" type="button">
                                    <span class='fa fa-key'></span>
                                </button></span>
                        </div>
                        <br>
                        <br>
                        <div class=" col-lg-12">
<button class='btn btn-primary' name="login_" type="submit">LOGIN
 
                                <span class="btn   btn-primary" type="button">
                                    <span class='fa fa-sign-in'></span>
</button>

                        </div>
                        <input type="checkbox" name="" id=""> forgot password
                    </form>
                </div>
            </div>
            <div class="text-center">
                <h1>Follow us</h1>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center v-center" style="font-size: 39pt;">
                    <a href="#"><span class="avatar"><i class="fa fa-google-plus"></i></span></a>
                    <a href="#"><span class="avatar"><i class="fa fa-linkedin"></i></span></a>
                    <a href="#"><span class="avatar"><i class="fa fa-facebook"></i></span></a>
                    <a href="#"><span class="avatar"><i class="fa fa-github"></i></span></a>
                </div>

            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->
    </div>    
</body>
</html>
