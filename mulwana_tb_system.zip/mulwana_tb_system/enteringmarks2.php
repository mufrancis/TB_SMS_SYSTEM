   <?php 
   
	$yearID=$_GET['yearID'];
$classID=$_GET['classID'];
$batchID=$_GET['batchID'];
$termID=$_GET['termID'];
$id=$_GET['id'];
   if($classID=='1'){
	   $sub1='Social';
	   $sub2='Reading';
	   $sub3='Language';
	   $sub4='Physical';
	   $sub5='Literacy';
	   $sub6='Academic';
	   $sub7='Numbers';
	   $sub8='Art';
	   $sub9='Writing';
	   $sub10='Music';
	   }
	   
	   
	   if($classID=='2' OR $classID=='3'){
	   $sub1='LA 1';
	   $sub2='LA 2';
	   $sub3='LA 3';
	   $sub4='LA 4';
	   $sub5='LA 5';
	   $sub6='Reading';
	   $sub7='';
	   $sub8='';
	   $sub9='';
	   $sub10='';
	   }
	    if($classID=='4' OR $classID=='5' OR $classID=='6'){
	   $sub1='ENG';
	   $sub2='MATH';
	   $sub3='LIT 1';
	   $sub4='LIT 2';
	   $sub5='LUG';
	   $sub6='R.E';
	   $sub7='READING';
	   $sub8='COMPUTER';
	   $sub9='';
	   $sub10='';
	   }
	   if($classID=='7' OR $classID=='8'){
	   $sub1='ENG';
	   $sub2='SCIE';
	   $sub3='MATHS';
	   $sub4='S.S.T';
	   $sub5='R.E';
	   $sub6='COMPUTER';
	   $sub7='';
	   $sub8='';
	   $sub9='';
	   $sub10='';
	   }
	   if($classID=='9' OR $classID=='10'){
	   $sub1='ENG';
	   $sub2='SCIE';
	   $sub3='MATHS';
	   $sub4='S.S.T';
	   $sub5='R.E';
	   $sub6='COMPUTER';
	   $sub7='';
	   $sub8='';
	   $sub9='';
	   $sub10='';
	   }
   ?>
   
   <script>
function bg_action(url) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("bg_div").innerHTML = xmlhttp.responseText;
            }else{
				document.getElementById("bg_div").innerHTML = "<center><br><br><br><img src='images/ajax-loader.gif' alt='Please wait....'/></center>";
			}
        }
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
   
}

</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="jquery.autosave.js"></script>
<script type="text/javascript" src="cufon-yui.js"></script>
<script type="text/javascript" src="Museo_400.font.js"></script>
<script type="text/javascript">
			Cufon.replace('h1',{fontFamily: 'Museo' });
</script>
<script	src="js/jquery.min.js"></script>
	<script	src="jquery.formnavigation.js"></script>
	<script>
	$(document).ready(function () {
		$('.gridexample').formNavigation();
	});
	</script>

<script type="text/javascript">
	$(function() {
	
		getDatabase();
		
		$("input,select,textarea").autosave({
			url: "autosave7.php",
			method: "post",
			grouped: true,
    		success: function(data) {
        		$("#message p").html("Data updated successfully").show();
				setTimeout('fadeMessage()',1500);
				getDatabase();
    		},
			send: function(){
        		$("#message p").html("Sending data....");
			},
    		dataType: "html"
		});		
		
		
	});
	
	function getDatabase(){
		indicator : '<img src="images/ajax-loader.gif">';

		$.get('autosave6.php?&yearID=<?php echo $yearID; ?>&termID=<?php echo $termID; ?>&classID=<?php echo $classID; ?>&subjectID=<?php echo $subjectID; ?>',
		

		 function(data) {
			
		  $('#database').html(data);
		  
		});	
	}
	
	function fadeMessage(){
		$('#message p').fadeOut('slow');
	}
	

	
</script>
<script>
/*!
* formNavigation
* Copyright 2015 C:\Wamp\....ehs\ANDREW
*/
(function ($) {
    $.fn.formNavigation = function () {
        $(this).each(function () {
            $(this).find('input').on('keyup', function(e) {
                switch (e.which) {
                    case 39:
                        $(this).closest('td').next().find('input').focus(); break;
                    case 37:
                        $(this).closest('td').prev().find('input').focus(); break;
                    case 40:
                        $(this).closest('tr').next().children().eq($(this).closest('td').index()).find('input').focus(); break;
                    case 38:
                        $(this).closest('tr').prev().children().eq($(this).closest('td').index()).find('input').focus(); break;
                }
            });
        });
    };
})(jQuery);</script>
<script>
 function validnum(a) {
    return ((a >= 0) && (a <= 101));
}
function validOrPunchTheUser(inputElement) {
    if(!validnum(inputElement.value)) {
        window.alert('Wrong Input data! Please enter mark in range of 0 to 100'); // punch the user
        inputElement.value = ""; // take away their things
    }
}
</script>
  <style type="text/css">
	
 
<!--
#hidden {
    display: none;
	width:
}
#n {
	height: 27.94cm;
	width: 21.59cm;
	
	
}
#nx {
	height: 27.94cm;
	width: 21.59cm;
	
	
}
#unique_table tr:hover{
	background-color:#0FF;
	
}
#allreport {
	
	width: 8.27in;
	height: 11.69in;
	
}
 
-->
    </style> 
   
   <div class="row" style="width:34cm;">
       
          <!-- Profile Image -->
          
        <!-- /.col -->
        <div class="col-md-10">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><!--<a href="#activity" data-toggle="tab">Type subject Name In Search Box</a>--></li>
              
             <a    type="button" class="btn btn-primary btn-lg"  href="insertsubjectstudents.php?&yearID=<?php echo $yearID; ?>&termID=<?php echo $termID; ?>&classID=<?php echo $classID; ?>&batchID=<?php echo $batchID; ?>">
				Generate Subject Mark Sheet</a>
                
                
                <a target="_blank"  class="btn btn-primary btn-lg" aria-labelledby="myModalLabel"  href="class_mark_sheet.php?yearID=<?php echo $yearID; ?>&termID=<?php echo $termID; ?>&classID=<?php echo $classID; ?>&batchID=<?php echo $batchID; ?>"> Mark Sheet</a>
             <!--  <li><a href="#timeline" data-toggle="tab">Generate Monthly Payroll</a></li>-->
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                <div class="post">
                  
            
            
            <div class="box-body">
             <?php
						
	
    $query =  "SELECT `x`.* FROM(SELECT marks2.studentID, students1.name,marks2.ID,marks2.sub1,marks2.sub2,marks2.sub3,marks2.sub4,marks2.sub5,marks2.sub6,marks2.sub7,marks2.sub8,marks2.sub9,marks2.sub10,marks2.batchID

FROM  `marks2`, students1 WHERE marks2.studentID = students1.ID AND marks2.yearID='$yearID'  AND marks2.classID='$classID' AND marks2.termID='$termID' AND marks2.batchID='$batchID')   AS `x` 

                             ORDER BY name ASC"; 
	 
	$query = mysql_query($query, $connect) or die(mysql_error());
	$row = mysql_fetch_assoc($query);
	
	$snvv =1;
	
	?>   
    <?php if($classID==1): ?>
    <form action="autosave7.php" method="post" enctype="multipart/form-data" class="form has-validation">
<input  name='yearID'  type="hidden"  value="<?php echo $yearID; ?>" />
            <input name='termID'   type="hidden" value="<?php echo $termID; ?>" />
            <input name='classID'  type="hidden" value="<?php echo $classID; ?>" />
            <input name='subjectID'  type="hidden" value="<?php echo $subjectID; ?>" />
             <table      class="table table-bordered table-striped table-hover gridexample" align="center" cellpadding="0" cellspacing="0" id="unique_table" style="font-size:12px; width:18cm;">
             <div align="center" style="background-color:#FCF;">Year:<?php echo GetFieldData($yearID, "years", "year"); ?>, Class: <?php echo GetFieldData($classID, "classes", "name"); ?>, Exam Batch: <?php echo GetFieldData($batchID, "accademic_batch", "name"); ?>  Marks Recording</div>
              
                <tr>
              
               <th>No</th>
                  <th width="250">Student Name</th>
               
                 
                  <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                  
                   <th align="center" width="98"><?php echo $sub7;?> </th>
                  <th align="center" width="98"><?php echo $sub8;?></th>
                  <th align="center" width="98"><?php echo $sub9;?></th>
                  <th align="center" width="98"><?php echo $sub10;?></th>
                
                
                  
                  
                </tr>
                
                 <?php
         $no=0;
         do { 
		
    
	   $no=$no+1;
		 
         
         ?>
               
                <tr>
                <input type="hidden"name="id[]" id="eeot40b<?php echo $no; ?>" value="<?php echo $row['ID'] ?>" />
                <td><?php echo $no;?></td>
               <?php if($row['studentID']>0){  ?>

                   <td  align="left" >
				<?php echo GetFieldData($row['studentID'], "students1", "name"); ?></td>
                <?php }else{ ?>
                <td ></td>
                <?php }?>
                
                
                
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub1;?>" onkeyup='validOrPunchTheUser(this)' name="sub1[]"  id="sub1b<?php echo $no; ?>" value="<?php echo $row['sub1'] ?>" onchange="bg_action('autosave7.php?sub1=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
               
               
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub2;?>" onkeyup='validOrPunchTheUser(this)' name="sub2[]"  id="sub2b<?php echo $no; ?>" value="<?php echo $row['sub2'] ?>" onchange="bg_action('autosave7.php?sub2=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
       
       
       <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub3;?>" onkeyup='validOrPunchTheUser(this)' name="sub3[]"  id="sub3b<?php echo $no; ?>" value="<?php echo $row['sub3'] ?>" onchange="bg_action('autosave7.php?sub3=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>        
               
               
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub4;?>" onkeyup='validOrPunchTheUser(this)' name="sub4[]"  id="sub4b<?php echo $no; ?>" value="<?php echo $row['sub4'] ?>" onchange="bg_action('autosave7.php?sub4=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub5;?>" onkeyup='validOrPunchTheUser(this)' name="sub5[]"  id="sub5b<?php echo $no; ?>" value="<?php echo $row['sub5']; ?>" onchange="bg_action('autosave7.php?sub5=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub6;?>" onkeyup='validOrPunchTheUser(this)' name="sub6[]"  id="sub6b<?php echo $no; ?>" value="<?php echo $row['sub6']; ?>" onchange="bg_action('autosave7.php?sub6=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub7;?>" onkeyup='validOrPunchTheUser(this)' name="sub7[]"  id="sub7b<?php echo $no; ?>" value="<?php echo $row['sub7']; ?>" onchange="bg_action('autosave7.php?sub7=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                 
                 
                 
                  <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub8;?>" onkeyup='validOrPunchTheUser(this)' name="sub8[]"  id="sub8b<?php echo $no; ?>" value="<?php echo $row['sub8']; ?>" onchange="bg_action('autosave7.php?sub8=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                  
                  
                   <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub9;?>" onkeyup='validOrPunchTheUser(this)' name="sub9[]"  id="sub9b<?php echo $no; ?>" value="<?php echo $row['sub9']; ?>" onchange="bg_action('autosave7.php?sub9=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub10=' + document.getElementById('sub10b<?php echo $no; ?>').value)"/></td>
                   
                   
                   <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub10;?>" onkeyup='validOrPunchTheUser(this)' name="sub10[]"  id="sub10b<?php echo $no; ?>" value="<?php echo $row['sub10']; ?>" onchange="bg_action('autosave7.php?sub10=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value + '&sub9=' + document.getElementById('sub9b<?php echo $no; ?>').value)"/></td>
                 
              
                  
                </tr>
                 <?php } while ($row = mysql_fetch_assoc($query)); ?>
               
                <th>No</th>
                 <th width="250">Student Name</th>
               
                <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                   
                   <th align="center" width="98"><?php echo $sub7;?> </th>
                  <th align="center" width="98"><?php echo $sub8;?></th>
                  <th align="center" width="98"><?php echo $sub9;?></th>
                  <th align="center" width="98"><?php echo $sub10;?></th>
                
                 
                
              </table>
              </form>
              <?php endif; ?>
              
              <?php if($classID==2 OR $classID==3): ?>
    <form action="autosave7.php" method="post" enctype="multipart/form-data" class="form has-validation">
<input  name='yearID'  type="hidden"  value="<?php echo $yearID; ?>" />
            <input name='termID'   type="hidden" value="<?php echo $termID; ?>" />
            <input name='classID'  type="hidden" value="<?php echo $classID; ?>" />
            <input name='subjectID'  type="hidden" value="<?php echo $subjectID; ?>" />
             <table      class="table table-bordered table-striped table-hover gridexample" align="center" cellpadding="0" cellspacing="0" id="unique_table" style="font-size:12px; width:18cm;">
             <div align="center" style="background-color:#FCF;">Year:<?php echo GetFieldData($yearID, "years", "year"); ?>, Class: <?php echo GetFieldData($classID, "classes", "name"); ?>, Exam Batch: <?php echo GetFieldData($batchID, "accademic_batch", "name"); ?>  Marks Recording</div>
              
                <tr>
              
               <th>No</th>
                  <th width="250">Student Name</th>
               
                 
                  <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                  
                  
                  
                  
                  
                </tr>
                
                 <?php
         $no=0;
         do { 
		
    
	   $no=$no+1;
		 
         
         ?>
               
                <tr>
                <input type="hidden"name="id[]" id="eeot40b<?php echo $no; ?>" value="<?php echo $row['ID'] ?>" />
                <td><?php echo $no;?></td>
               <?php if($row['studentID']>0){  ?>

                   <td  align="left" >
				<?php echo GetFieldData($row['studentID'], "students1", "name"); ?></td>
                <?php }else{ ?>
                <td ></td>
                <?php }?>
                
                
                
                
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub1;?>" onkeyup='validOrPunchTheUser(this)' name="sub1[]"  id="sub1b<?php echo $no; ?>" value="<?php echo $row['sub1'] ?>" onchange="bg_action('autosave7.php?sub1=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
               
               
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub2;?>" onkeyup='validOrPunchTheUser(this)' name="sub2[]"  id="sub2b<?php echo $no; ?>" value="<?php echo $row['sub2'] ?>" onchange="bg_action('autosave7.php?sub2=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
       
       
       <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub3;?>" onkeyup='validOrPunchTheUser(this)' name="sub3[]"  id="sub3b<?php echo $no; ?>" value="<?php echo $row['sub3'] ?>" onchange="bg_action('autosave7.php?sub3=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value )"/></td>        
               
               
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub4;?>" onkeyup='validOrPunchTheUser(this)' name="sub4[]"  id="sub4b<?php echo $no; ?>" value="<?php echo $row['sub4'] ?>" onchange="bg_action('autosave7.php?sub4=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub5;?>" onkeyup='validOrPunchTheUser(this)' name="sub5[]"  id="sub5b<?php echo $no; ?>" value="<?php echo $row['sub5']; ?>" onchange="bg_action('autosave7.php?sub5=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub6;?>" onkeyup='validOrPunchTheUser(this)' name="sub6[]"  id="sub6b<?php echo $no; ?>" value="<?php echo $row['sub6']; ?>" onchange="bg_action('autosave7.php?sub6=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value  )"/></td>
                 
                 
                 
                 
                  
                </tr>
                 <?php } while ($row = mysql_fetch_assoc($query)); ?>
               
                <th>No</th>
                 <th width="250">Student Name</th>
               
                <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                  
                
              </table>
              </form>
              <?php endif; ?>
              
              <?php if($classID==4 OR $classID==5 OR $classID==6): ?>
    <form action="autosave7.php" method="post" enctype="multipart/form-data" class="form has-validation">
<input  name='yearID'  type="hidden"  value="<?php echo $yearID; ?>" />
            <input name='termID'   type="hidden" value="<?php echo $termID; ?>" />
            <input name='classID'  type="hidden" value="<?php echo $classID; ?>" />
            <input name='subjectID'  type="hidden" value="<?php echo $subjectID; ?>" />
             <table      class="gridexample" align="center" cellpadding="0" cellspacing="0" id="unique_table" style="font-size:12px; width:18cm;">
             <div align="center" style="background-color:#FCF;">Year:<?php echo GetFieldData($yearID, "years", "year"); ?>, Class: <?php echo GetFieldData($classID, "classes", "name"); ?>, Exam Batch: <?php echo GetFieldData($batchID, "accademic_batch", "name"); ?>  Marks Recording</div>
              
                <tr>
              
               <th>No</th>
                  <th width="250">Student Name</th>
               
                 
                  <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                  
                   <th align="center" width="98"><?php echo $sub7;?> </th>
                  <th align="center" width="98"><?php echo $sub8;?></th>
                 
                
                 
                  
                </tr>
                
                 <?php
         $no=0;
         do { 
		
    
	   $no=$no+1;
		 
         
         ?>
               
                <tr>
                <input type="hidden"name="id[]" id="eeot40b<?php echo $no; ?>" value="<?php echo $row['ID'] ?>" />
                <td><?php echo $no;?></td>
               <?php if($row['studentID']>0){  ?>

                   <td  align="left" >
				<?php echo GetFieldData($row['studentID'], "students1", "name"); ?></td>
                <?php }else{ ?>
                <td ></td>
                <?php }?>
                
                
                
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub1;?>" onkeyup='validOrPunchTheUser(this)' name="sub1[]"  id="sub1b<?php echo $no; ?>" value="<?php echo $row['sub1'] ?>" onchange="bg_action('autosave7.php?sub1=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
               
               
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub2;?>" onkeyup='validOrPunchTheUser(this)' name="sub2[]"  id="sub2b<?php echo $no; ?>" value="<?php echo $row['sub2'] ?>" onchange="bg_action('autosave7.php?sub2=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
       
       
       <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub3;?>" onkeyup='validOrPunchTheUser(this)' name="sub3[]"  id="sub3b<?php echo $no; ?>" value="<?php echo $row['sub3'] ?>" onchange="bg_action('autosave7.php?sub3=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>        
               
               
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub4;?>" onkeyup='validOrPunchTheUser(this)' name="sub4[]"  id="sub4b<?php echo $no; ?>" value="<?php echo $row['sub4'] ?>" onchange="bg_action('autosave7.php?sub4=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub5;?>" onkeyup='validOrPunchTheUser(this)' name="sub5[]"  id="sub5b<?php echo $no; ?>" value="<?php echo $row['sub5']; ?>" onchange="bg_action('autosave7.php?sub5=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub6;?>" onkeyup='validOrPunchTheUser(this)' name="sub6[]"  id="sub6b<?php echo $no; ?>" value="<?php echo $row['sub6']; ?>" onchange="bg_action('autosave7.php?sub6=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub7;?>" onkeyup='validOrPunchTheUser(this)' name="sub7[]"  id="sub7b<?php echo $no; ?>" value="<?php echo $row['sub7']; ?>" onchange="bg_action('autosave7.php?sub7=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub8=' + document.getElementById('sub8b<?php echo $no; ?>').value )"/></td>
                 
                 
                 
                  <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub8;?>" onkeyup='validOrPunchTheUser(this)' name="sub8[]"  id="sub8b<?php echo $no; ?>" value="<?php echo $row['sub8']; ?>" onchange="bg_action('autosave7.php?sub8=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value + '&sub7=' + document.getElementById('sub7b<?php echo $no; ?>').value )"/></td>
                  
                  
                 
                 
                  
                </tr>
                 <?php } while ($row = mysql_fetch_assoc($query)); ?>
               
                <th>No</th>
                 <th width="250">Student Name</th>
               
                <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                   
                   <th align="center" width="98"><?php echo $sub7;?> </th>
                  <th align="center" width="98"><?php echo $sub8;?></th>
                  
                  
                
              </table>
              </form>
              <?php endif; ?>
              
              <?php if($classID>6): ?>
    <form action="autosave7.php" method="post" enctype="multipart/form-data" class="form has-validation">
<input  name='yearID'  type="hidden"  value="<?php echo $yearID; ?>" />
            <input name='termID'   type="hidden" value="<?php echo $termID; ?>" />
            <input name='classID'  type="hidden" value="<?php echo $classID; ?>" />
            <input name='subjectID'  type="hidden" value="<?php echo $subjectID; ?>" />
             <table      class="table table-bordered table-striped table-hover gridexample" align="center" cellpadding="0" cellspacing="0" id="unique_table" style="font-size:12px; width:18cm;">
             <div align="center" style="background-color:#FCF;">Year:<?php echo GetFieldData($yearID, "years", "year"); ?>, Class: <?php echo GetFieldData($classID, "classes", "name"); ?>, Exam Batch: <?php echo GetFieldData($batchID, "accademic_batch", "name"); ?>  Marks Recording</div>
              
                <tr>
              
               <th>No</th>
                  <th width="250">Student Name</th>
               
                 
                  <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                 
                  
                  
                </tr>
                
                 <?php
         $no=0;
         do { 
		
    
	   $no=$no+1;
		 
         
         ?>
               
                <tr>
                <input type="hidden"name="id[]" id="eeot40b<?php echo $no; ?>" value="<?php echo $row['ID'] ?>" />
                <td><?php echo $no;?></td>
               <?php if($row['studentID']>0){  ?>

                   <td  align="left" >
				<?php echo GetFieldData($row['studentID'], "students1", "name"); ?></td>
                <?php }else{ ?>
                <td ></td>
                <?php }?>
                
                
                
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub1;?>" onkeyup='validOrPunchTheUser(this)' name="sub1[]"  id="sub1b<?php echo $no; ?>" value="<?php echo $row['sub1'] ?>" onchange="bg_action('autosave7.php?sub1=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
               
               
               <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub2;?>" onkeyup='validOrPunchTheUser(this)' name="sub2[]"  id="sub2b<?php echo $no; ?>" value="<?php echo $row['sub2'] ?>" onchange="bg_action('autosave7.php?sub2=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
       
       
       <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub3;?>" onkeyup='validOrPunchTheUser(this)' name="sub3[]"  id="sub3b<?php echo $no; ?>" value="<?php echo $row['sub3'] ?>" onchange="bg_action('autosave7.php?sub3=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value )"/></td>        
               
               
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub4;?>" onkeyup='validOrPunchTheUser(this)' name="sub4[]"  id="sub4b<?php echo $no; ?>" value="<?php echo $row['sub4'] ?>" onchange="bg_action('autosave7.php?sub4=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub5;?>" onkeyup='validOrPunchTheUser(this)' name="sub5[]"  id="sub5b<?php echo $no; ?>" value="<?php echo $row['sub5']; ?>" onchange="bg_action('autosave7.php?sub5=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub6=' + document.getElementById('sub6b<?php echo $no; ?>').value  )"/></td>
                 
                 
                 <td align="center" ><input type="text" style="width:1.8cm;" placeholder="<?php echo $sub6;?>" onkeyup='validOrPunchTheUser(this)' name="sub6[]"  id="sub6b<?php echo $no; ?>" value="<?php echo $row['sub6']; ?>" onchange="bg_action('autosave7.php?sub6=' + this.value + '&id=' + document.getElementById('eeot40b<?php echo $no; ?>').value + '&sub1=' + document.getElementById('sub1b<?php echo $no; ?>').value + '&sub2=' + document.getElementById('sub2b<?php echo $no; ?>').value + '&sub3=' + document.getElementById('sub3b<?php echo $no; ?>').value + '&sub4=' + document.getElementById('sub4b<?php echo $no; ?>').value + '&sub5=' + document.getElementById('sub5b<?php echo $no; ?>').value  )"/></td>
                 
               
                  
                </tr>
                 <?php } while ($row = mysql_fetch_assoc($query)); ?>
               <tr>
                <th>No</th>
                 <th width="250">Student Name</th>
               
                <th align="center" width="98"><?php echo $sub1;?> </th>
                  <th align="center" width="98"><?php echo $sub2;?></th>
                  <th align="center" width="98"><?php echo $sub3;?></th>
                   <th align="center" width="98"><?php echo $sub4;?> </th>
                  <th align="center" width="98"><?php echo $sub5;?></th>
                  <th align="center" width="98"><?php echo $sub6;?></th>
                  </tr>
              </table>
              </form>
              <?php endif;?>
              
            </div>
        
                </div>
               
              </div>
              <div class="tab-pane" id="timeline">
              <form class="form has-validation" enctype="multipart/form-data"   action="backend.php?generateemployees=true" method="post" >
  <fieldset>
              
               <input name="districtID" type="hidden" value="<?php echo $districtID; ?>" />
               <legend style="color:#F00;">Generate Monthly Payroll</legend>
              
                
                       


                   
                  
<div class="form-group">

                    <label for="inputEmail" class="col-sm-2 control-label">Years<em>*</em></label>

                   
                    <div class="col-md-3">
                       <select name="year" required id="year" class="form-control select2" style="width: 100%;">
                    <option value="<?php echo GetFieldData($yearID, "years", "year"); ?>" ><?php echo GetFieldData($yearID, "years", "year"); ?></option>
              
							<?php      
                
                             
							  	$sql 		= "SELECT * FROM years ORDER BY ID DESC";
							  
                              $qry 		= mysql_query($sql);
                              $rows 	= mysql_num_rows($qry);
                
                              if ( $rows > 0) 
                              {
                                  for($a=0;$a<$rows;$a++)
                                  {
                                        $row = mysql_fetch_array($qry); 
                                        
                                        $id 		= $row['ID'];
										$Name 		= $row['year'];
                                                                        
                                        echo "<option value='$Name'>$Name</option>";
                                        
                                  }
                              }
                              
                              ?>
    </select>
</div></div>
                   </p><br/>
                   <div class="form-group">

                    <label for="inputEmail" class="col-sm-2 control-label">Months<em>*</em></label>

                   <div class="col-md-3">
                       <select name="month" required id="month" class="form-control select2" style="width: 100%;">
                    <option value="" selected disabled>Select Month</option>
                    <option value="01">January</option>
                    <option value="02">February</option>
                    <option value="03">March</option>
                    <option value="04">April</option>
                    <option value="05">May</option>
                    <option value="06">June</option>
                    <option value="07">July</option>
                    <option value="08">August</option>
                    <option value="09">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>
                    
                    </select>
</div></div>
                   </p>
                        
                    
                        
                     
                        
                
                   
                   
                   

                    
                      
                        
              
                        
                      

                   

              
                <hr class="clear" />
                
            

               

                <div style="height:1cm;" class="form-action clearfix">
               

                    <button class="button button-gray" type="submit" data-icon-primary="ui-icon-circle-check">Generate Pay Roll</button>

                    


                </div>
                </fieldset>

            </form>
              </div>
              <div class="tab-pane" id="settings">
               <div class="box">
            <div align="center" class="box-header">
              <h3 class="box-title">Allocation by Selecting class 1st</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <form class="form-horizontal" action="dashboard.php?p=allocateclass" enctype="multipart/form-data" method="post">
                
                 <div class="col-md-1">
                <label>Year</label>
                <div class="form-group">
                <select name="yearID" required id="yearID1x" class="form-control select2" style="width: 100%;">
                  
                    <option value="<?php echo $yearID; ?>" ><?php echo GetFieldData($yearID, "years", "year"); ?></option>
              
							<?php      
                
                             
							  	$sql 		= "SELECT * FROM years ORDER BY year DESC";
							  
                              $qry 		= mysql_query($sql);
                              $rows 	= mysql_num_rows($qry);
                
                              if ( $rows > 0) 
                              {
                                  for($a=0;$a<$rows;$a++)
                                  {
                                        $row = mysql_fetch_array($qry); 
                                        
                                        $id 		= $row['ID'];
										$Name 		= $row['year'];
                                                                        
                                        echo "<option value='$id'>$Name</option>";
                                        
                                  }
                              }
                              
                              ?>
    </select>
              </div>
               </div>  
                 <div class="col-md-4">
                <label>Year Classes</label>
                <div class="form-group">
                <select name="classID" required id="classIDx" class="form-control select2" style="width: 100%;">
                  
                   <option value="" selected disabled>Select Year Class</option>
              
							<?php      
                
                             
							  	$sql 		= "SELECT * FROM classes ORDER BY name ASC";
							  
                              $qry 		= mysql_query($sql);
                              $rows 	= mysql_num_rows($qry);
                
                              if ( $rows > 0) 
                              {
                                  for($a=0;$a<$rows;$a++)
                                  {
                                        $row = mysql_fetch_array($qry); 
                                        
                                        $id 		= $row['ID'];
										$Name 		= $row['name'];
                                                                        
                                        echo "<option value='$id'>$Name</option>";
                                        
                                  }
                              }
                              
                              ?>
    </select>
              </div>
               </div>  
               
               
              
               
                
              
                    
               
                 
                  
                   
                   
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
               </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
   
 
  <!-- /.content-wrapper -->
 </div>

  
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
     $("#example1").DataTable(
	{
     "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
	  "aaSorting": [[0,'desc']],
	  "iDisplayLength": 1000,
      "autoWidth": false
    }
	);
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>

