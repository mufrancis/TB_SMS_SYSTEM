<?php
// include_once('connection/connect.php');
// var_dump($)
function direct($page) {
    if($page !==""){
        header("location:{$page}");
    };
}
	function login($link_connector){
        $user_name=(str_replace("'#","hakers",mysqli_real_escape_string( $link_connector,$_REQUEST['Email'])));
        $password=(str_replace("'#","hakers",mysqli_real_escape_string( $link_connector,$_REQUEST['password'])));
        // var_dump($password);
        if( $user_name!='NULL' || $password!='NULL' ){
            $select=("SELECT * FROM `users` WHERE  `username`='$user_name' AND `password`='".sha1($password)."' LIMIT 1");
            // var_dump($select);
        $results=mysqli_query($link_connector,$select);
            if(mysqli_num_rows($results)>0){
                while($found_user = mysqli_fetch_array($results)){
                    $_SESSION['valid']=$found_user['tell'];
                    $_SESSION['user_id']=$found_user['ID'];
                    $_SESSION['dr_email']=$found_user['username'];
                    $_SESSION['post']=$found_user['post'];
                    if($found_user['post']==='admin'){
             direct("admin.php?section=".$found_user['post']);
            }else{     
                direct("service_providers.php?section=".$found_user['post']);
            }
        }
            }else {
            ?><script>alert ("Username/password combination incorrect.Please make sure your caps lock key is off and try again  I've not got this match NAME && PASWORD","",0);
            </script><?php
            ;}
        ;}else {?><script>
            alert("Please all fields required!")
            </script><?php
        }
        ;}
        
        
?>