
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Suvice Provider Dashboard </title>

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/local.css" />
    <link rel="stylesheet" href="./js/dataTables.bootstrap.css">

    <!-- <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script> -->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <script   src="js/jquery.dataTables.js"></script>
    <!-- <link type="text/javascript" src="js/dataTables.bootstrap.css"/> -->
    <script type="text/javascript"  src="js/functions.js"></script>
    <script type="text/javascript"  src="js/pom.js"></script>
    <link rel="stylesheet" href="js/alertify/themes/alertify.core.css">
    <link rel="stylesheet" href="js/alertify/themes/alertify.default.css">
    <!-- you need to include the shieldui css and js assets in order for the charts to work -->
    <!-- <link rel="stylesheet" type="text/css" href="http://www.shieldui.com/shared/components/latest/css/light-bootstrap/all.min.css" /> -->
    <!-- <link id="gridcss" rel="stylesheet" type="text/css" href="http://www.shieldui.com/shared/components/latest/css/dark-bootstrap/all.min.css" /> -->

    <!-- <script type="text/javascript" src="http://www.shieldui.com/shared/components/latest/js/shieldui-all.min.js"></script> -->
    <!-- <script type="text/javascript" src="http://www.prepbootstrap.com/Content/js/gridData.js"></script> -->
    <style>

div {
    padding-bottom:20px;
}

</style>
</head>
<body>
<div class="example-modal hidden pomscroll2 ">
            <div class="modal">
                <div class=" modal-dialog">
                    <div class="modal-content" id="modal">
                        <div class="modal-header">
                            <button type="button" class="close  " data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title">Default Modal</h4>
                        </div>
                        <form class='panel universalId-form' id='' method='post' style='    margin: 1em;overflow: auto;height: min-content;max-height: 37em;'>
                            <input type="hidden" name='universalId' value='' id='universalId'>

                            <div class="modal-body">

                                <p>One fine body&hellip;</p>
                            </div>
                        </form>
                        <div class="modal-footer">
                            <!-- <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button> -->
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->
        </div>
    </div>
    <div id="wrapper">
    <style>
        .modal {
    /* display: none !important; */
    overflow: auto !important;
    overflow-y: scroll !important;
    position: fixed !important;
    top: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    left: 0 !important;
    z-index: 1050 !important;
    -webkit-overflow-scrolling: touch !important;
    outline: 0 !important;
}
.modal {
    position: fixed !important;
    top: 0;
    right: 0 !important;
    bottom: 0;
    left: 0 !important;
    z-index: 1050 !important;
    display: none;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch !important;
    outline: 0 !important;
        }
        .example-modal .modal {
            position: relative;
            top: auto;
            bottom: auto;
            right: auto;
            left: auto;
            display: block;
            z-index: 1;
        }

        .example-modal .modal {
            background: transparent !important;
        }</style>
  
          <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Service Provider Panel</a>
            </div>


            
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul id="active" class="nav navbar-nav side-nav">
                    <li class="selected"><a href="#"><i class="fa fa-bullseye"></i> Dashboard</a></li>
                    <!-- <li><a href="portfolio.html"><i class="fa fa-tasks"></i> Portfolio</a></li> -->
                    <!-- <li><a href="blog.html"><i class="fa fa-globe"></i> Blog</a></li> -->
            <!-- <li><a href="signup.html"><i class="fa fa-list-ol"></i> SignUp</a></li> -->
            <li><a href="#" page='register.php?register_news=remaidars-drags' class='page-link' pname='Remaider'>
                <i class="fa fa-star"></i>Remaider</a></li>
                <li><a href="#" page='register.php?register_news=message ' class='page-link' pname='All messages'><i class="fa fa-users"></i>Messages</a></li>

                    <!-- <li><a href="timeline.html"><i class="fa fa-font"></i> Timeline</a></li> -->
                    <!-- <li><a href="forms.html"><i class="fa fa-list-ol"></i> Forms</a></li> -->
                    <!-- <li><a href="typography.html"><i class="fa fa-font"></i> Typography</a></li> -->
                    <!-- <li><a href="bootstrap-elements.html"><i class="fa fa-list-ul"></i> Bootstrap Elements</a></li> -->
                    <!-- <li><a href="bootstrap-grid.html"><i class="fa fa-table"></i> Bootstrap Grid</a></li> -->
                </ul>
                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown messages-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> Messages <span class="badge">2</span> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li class="dropdown-header">2 New Messages</li>
                            <li class="message-preview">
                                <a href="#">
                                    <span class="avatar"><i class="fa fa-bell"></i></span>
                                    <span class="message">Security alert</span>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li class="message-preview">
                                <a href="#">
                                    <span class="avatar"><i class="fa fa-bell"></i></span>
                                    <span class="message">Security alert</span>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="#">Go to Inbox <span class="badge">2</span></a></li>
                        </ul>
                    </li><?php 
                    // session_start();
  $sender=($_SESSION['valid']);
                    
                    
                    ?>
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?=$sender?><b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li><a href="#"><i class="fa fa-gear"></i> Settings</a></li>
                            <li class="divider"></li>
                            <li><a href="logout"><i class="fa fa-power-off"></i> Log Out</a></li>

                        </ul>
                    </li>
                    <li class="divider-vertical"></li>
                    <li>
                        <form class="navbar-search">
                            <input type="text" placeholder="Search" class="form-control">
                        </form>
                    </li>
                </ul>
            </div>
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class='localmotion' id='localmotion'>Dashboard </h1>
                    <div class="col-lg-12 "  >

                     <!--   <div class="alert alert-dismissable alert-warning">
                            <button data-dismiss="alert" class="close" type="button">&times;</button>
                            mavins oooooo
                        Welcome to the admin dashboard! Feel free to review all pages and modify the layout to your needs. 
                        <br />
                        This theme uses the <a href="https://www.shieldui.com">ShieldUI</a> JavaScript library for the 
                        additional data visualization and presentation functionality illustrated here.
                    </div>
                 </span> -->
                </div>
            </div>




            