<?php 
include_once('connection/connect.php');
session_start();
ob_start();
include_once("snipets/providers_header.php");
if(!isset($_SESSION['valid']) ){
    header("location:login.php");
      }else {
          
      }
?>
           <div class='dashboard'>
           <div class="row">

<div class="col-md-8" >
 







    <div class="panel panel-primary">
        <div class="panel-heading">
              <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Visits Based on a 10 days data mavin</h3>
        </div>
        <div class="panel-body">
            <div id="shieldui-chart1"></div>
        </div>
    </div>
</div>
<div class="col-md-4">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-rss"></i> Feed</h3>
        </div>
        <div class="panel-body feed">
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-comment"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        <a href="#">John Doe</a> commented on <a href="#">What Makes Good Code Good</a>.
                    </div>
                    <div class="time pull-left">
                        3 h
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-check"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        <a href="#">Merge request #42</a> has been approved by <a href="#">Jessica Lori</a>.
                    </div>
                    <div class="time pull-left">
                        10 h
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-plus-square-o"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        New user <a href="#">Greg Wilson</a> registered.
                    </div>
                    <div class="time pull-left">
                        Today
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-bolt"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        Server fail level raises above normal. <a href="#">See logs</a> for details.
                    </div>
                    <div class="time pull-left">
                        Yesterday
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-archive"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        <a href="#">Database usage report</a> is ready.
                    </div>
                    <div class="time pull-left">
                        Yesterday
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-shopping-cart"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        <a href="#">Order #233985</a> needs additional processing.
                    </div>
                    <div class="time pull-left">
                        Wednesday
                    </div>
                </div>
            </section>
            <section class="feed-item">
                <div class="icon pull-left">
                    <i class="fa fa-arrow-down"></i>
                </div>
                <div class="feed-item-body">
                    <div class="text">
                        <a href="#">Load more...</a>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
</div>
<div class="row">
<div class="col-lg-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Traffic Sources One month tracking </h3>
        </div>
        <div class="panel-body">
            <div id="shieldui-grid1"></div>
        </div>
    </div>
</div>
</div>
<div class="row">
<div class="col-lg-4">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Logins per week</h3>
        </div>
        <div class="panel-body">
            <div id="shieldui-chart2"></div>
        </div>
    </div>
</div>
<div class="col-lg-4">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-magnet"></i> Server Overview</h3>
        </div>
        <div class="panel-body">
            <ul class="server-stats">
                <li>
                    <div class="key pull-right">CPU</div>
                    <div class="stat">
                        <div class="info">60% / 37°C / 3.3 Ghz</div>
                        <div class="progress progress-small">
                            <div style="width: 70%;" class="progress-bar progress-bar-danger"></div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="key pull-right">Mem</div>
                    <div class="stat">
                        <div class="info">29% / 4GB (16 GB)</div>
                        <div class="progress progress-small">
                            <div style="width: 29%;" class="progress-bar"></div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="key pull-right">LAN</div>
                    <div class="stat">
                        <div class="info">6 Mb/s <i class="fa fa-caret-down"></i>&nbsp; 3 Mb/s <i class="fa fa-caret-up"></i></div>
                        <div class="progress progress-small">
                            <div style="width: 48%;" class="progress-bar progress-bar-inverse"></div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>

</div>
<div class="col-lg-4">
    <header>
        <ul class="nav nav-tabs">
            <li class="active">
                <a data-toggle="tab" href="#stats">Users</a>
            </li>
            <li class="">
                <a data-toggle="tab" href="#report">Favorites</a>
            </li>
            <li class="">
                <a data-toggle="tab" href="#dropdown1">Commenters</a>
            </li>
        </ul>
    </header>
    <div class="body tab-content">
        <div class="tab-pane clearfix active" id="stats">
            <h5 class="tab-header"><i class="fa fa-calendar-o fa-2x"></i> Last logged-in users</h5>
            <ul class="news-list">
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Ivan Gorge</a></div>
                        <div class="position">Software Engineer</div>
                        <div class="time">Last logged-in: Mar 12, 11:11</div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Roman Novak</a></div>
                        <div class="position">Product Designer</div>
                        <div class="time">Last logged-in: Mar 12, 19:02</div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Teras Uotul</a></div>
                        <div class="position">Chief Officer</div>
                        <div class="time">Last logged-in: Jun 16, 2:34</div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Deral Ferad</a></div>
                        <div class="position">Financial Assistant</div>
                        <div class="time">Last logged-in: Jun 18, 4:20</div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Konrad Polerd</a></div>
                        <div class="position">Sales Manager</div>
                        <div class="time">Last logged-in: Jun 18, 5:13</div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="tab-pane" id="report">
            <h5 class="tab-header"><i class="fa fa-star fa-2x"></i> Popular contacts</h5>
            <ul class="news-list news-list-no-hover">
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Pol Johnsson</a></div>
                        <div class="options">
                            <button class="btn btn-xs btn-success">
                                <i class="fa fa-phone"></i>
                                Call
                            </button>
                            <button class="btn btn-xs btn-warning">
                                <i class="fa fa-envelope-o"></i>
                                Message
                            </button>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Terry Garel</a></div>
                        <div class="options">
                            <button class="btn btn-xs btn-success">
                                <i class="fa fa-phone"></i>
                                Call
                            </button>
                            <button class="btn btn-xs btn-warning">
                                <i class="fa fa-envelope-o"></i>
                                Message
                            </button>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Eruos Forkal</a></div>
                        <div class="options">
                            <button class="btn btn-xs btn-success">
                                <i class="fa fa-phone"></i>
                                Call
                            </button>
                            <button class="btn btn-xs btn-warning">
                                <i class="fa fa-envelope-o"></i>
                                Message
                            </button>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Remus Reier</a></div>
                        <div class="options">
                            <button class="btn btn-xs btn-success">
                                <i class="fa fa-phone"></i>
                                Call
                            </button>
                            <button class="btn btn-xs btn-warning">
                                <i class="fa fa-envelope-o"></i>
                                Message
                            </button>
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Lover Lund</a></div>
                        <div class="options">
                            <button class="btn btn-xs btn-success">
                                <i class="fa fa-phone"></i>
                                Call
                            </button>
                            <button class="btn btn-xs btn-warning">
                                <i class="fa fa-envelope-o"></i>
                                Message
                            </button>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="tab-pane" id="dropdown1">
            <h5 class="tab-header"><i class="fa fa-comments fa-2x"></i> Top Commenters</h5>
            <ul class="news-list">
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Edin Garey</a></div>
                        <div class="comment">
                            Nemo enim ipsam voluptatem quia voluptas sit aspernatur 
                            aut odit aut fugit,sed quia
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Firel Lund</a></div>
                        <div class="comment">
                            Duis aute irure dolor in reprehenderit in voluptate velit
                             esse cillum dolore eu fugiat.
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Jessica Desingter</a></div>
                        <div class="comment">
                            Excepteur sint occaecat cupidatat non proident, sunt in
                             culpa qui officia deserunt.
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Novel Forel</a></div>
                        <div class="comment">
                            Sed ut perspiciatis, unde omnis iste natus error sit voluptatem accusantium doloremque.
                        </div>
                    </div>
                </li>
                <li>
                    <i class="fa fa-user fa-4x pull-left"></i>
                    <div class="news-item-info">
                        <div class="name"><a href="#">Wedol Reier</a></div>
                        <div class="comment">
                            Laudantium, totam rem aperiam eaque ipsa, quae ab illo inventore veritatis
                            et quasi.
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
</div>
</div>
</div>
           </div>
    <!-- /#wrapper -->
    <!-- this is where i call in the javascript   -->
    
    <script src="js/alertify/alertify.min.js"></script>

    <script type="text/javascript">
        jQuery(function ($) {
            
            // var performance = [12, 43, 34, 22, 12, 33, 4, 17, 22, 34, 54, 67],
            //     visits = [123, 323, 443, 32],
            //     traffic = [
            //     {
            //         Source: "Direct", Amount: 323, Change: 53, Percent: 23, Target: 600
            //     },
            //     {
            //         Source: "Refer", Amount: 345, Change: 34, Percent: 45, Target: 567
            //     },
            //     {
            //         Source: "Social", Amount: 567, Change: 67, Percent: 23, Target: 456
            //     },
            //     {
            //         Source: "Search", Amount: 234, Change: 23, Percent: 56, Target: 890
            //     },
            //     {
            //         Source: "Internal", Amount: 111, Change: 78, Percent: 12, Target: 345
            //     }];


            // $("#shieldui-chart1").shieldChart({
            //     theme: "dark",

            //     primaryHeader: {
            //         text: "Visitors"
            //     },
            //     exportOptions: {
            //         image: false,
            //         print: false
            //     },
            //     dataSeries: [{
            //         seriesType: "area",
            //         collectionAlias: "Q Data",
            // //         data: performance
            // //     }]
            // // });

            // $("#shieldui-chart2").shieldChart({
            //     theme: "dark",
            //     primaryHeader: {
            //         text: "Traffic Per week"
            //     },
            //     exportOptions: {
            //         image: false,
            //         print: false
            //     },
            //     dataSeries: [{
            //         seriesType: "pie",
            //         collectionAlias: "traffic",
            //         data: visits
            //     }]
            // });

            // $("#shieldui-grid1").shieldGrid({
            //     dataSource: {
            //         data: traffic
            //     },
            //     sorting: {
            //         multiple: true
            //     },
            //     rowHover: false,
            //     paging: false,
            //     columns: [
            //     { field: "Source", width: "170px", title: "Source" },
            //     { field: "Amount", title: "Amount" },                
            //     { field: "Percent", title: "Percent", format: "{0} %" },
            //     { field: "Target", title: "Target" },
            //     ]
            // });            
        // });        
    </script>
</body>
</html>
