<?php session_start(); ob_start();
include_once('../connection/connect.php');
$connection=  $link_connector; $tbodys_rows='';
if ($_REQUEST['register_news']==='patients') {
    $facility_name='';
    $dr_gender='';
    $doctor='';
    $dr_contact='';
    $email='';
    $dr_email='';
    $Name='';
    $tell='';
    $place_of_stay='';
    $sptr_contact='';
    $sptr_village='';
    $drag_time_set='';
    if(isset($_REQUEST['fetchedID'])){
        if ($result = $connection->query("SELECT * FROM `patient` where  `pt_ID`=".$_REQUEST['fetchedID']."  order by Name asc limit 1 ")) { 
        
            if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
        if ($result->num_rows>0) {
           $i=0;
        
            while ($row = $result->fetch_assoc()) { $i++;
                extract($row);
                // var_dump($Name);
                
    }
    }
    }
    }
?>
<!-- 
        <div class="row text-center">
            <h2>New Registration</h2>
        </div> -->
        <form action="" class="form-horizontal" id='New_patient'>
            <?php
            if(isset($_REQUEST['fetchedID'])){
                echo "<input type=\"text\" class=\"form-control\" value=".$_REQUEST['fetchedID']."   name='Patient_id'  required />"
;
            }
            ?>
        <div class=" col-lg-12 col-md-6">
        <div class="col-md-6">
        <label for="HOSPITAL-DATA" class="col-lg-12 col-md-12 btn btn-default btn-block">HOSPITAL-DATA</label>
        <br>
        <br>
        <br>
        <label for="lastname" class="col-md-2">  Hospital Name:  </label>
            <div class="col-md-9">
                <input type="text" class="form-control" value='<?=$facility_name?>' id="lastname" name='hospital-name'  required placeholder="Enter Facility Name">
            </div>
             <div class="col-md-1">
                <i class="fa fa-hospital-o fa-1x"></i>
            </div>
            <!--  -->

            <h3 class='text-center'>Doctor Info <span class="fa fa-info btn "></span></h3>
            <div>
            <label for="uploadimage" class="col-md-2">
                Upload Image:
            </label>
            <div class="col-md-10">
                <input type="file" name="uploadimage" disabled id="uploadimage">
                <p class="help-block">
                    Allowed formats: jpeg, jpg, gif, png
                </p>
            </div>          
        </div>

        <div>
            <label for="sex" class="col-md-2">
                Gender:
            </label>
            <?php 
        $dr_gender_set_male=($dr_gender=='male')?"selected":"";
        $dr_gender_set_fmale=($dr_gender=='female')?"selected":"";
            ?>
            <div class="col-md-10">
                <span class="fa fa-male"></span>
                <input type="radio" <?=$dr_gender_set_male?>  name="dr_sex" id="sex" value="male" checked>
                Male
                <input type="radio" <?=$dr_gender_set_fmale?> name="dr_sex" id="Radio1" value="female">
                <span class="fa fa-female"></span>
                    Female
            </div>             
        </div>
        <label for="DRname" class="col-md-2">Names:  </label>
            <div class="col-md-9">
                <input type="text" class="form-control" value="<?=$doctor?>" id="lastname" name='Dr-name'  required placeholder="Enter Doctor's Name">
            </div>
             <div class="col-md-1">
                <i class="fa fa-user-md fa-1x"></i>
            </div>
            </div>
            <!--  -->
            <div class=" btn btn-bloc k btn-default col-lg-6 ">MORE INFO</div>
            <div class="col-md-6">
                    <br>
     <label for="contact" class="col-md-2"> Contact:  </label>
            <div class="col-md-9">
                <input type="tel" value="<?=$dr_contact?>" class="form-control" id="lastname" pattern="^[07]{1}\d{8,9}" name='Dr-contact'  required placeholder="Enter Doctor's contact">
            </div>
             <div class="col-md-1">
                <i class="fa fa-phone fa-1x"></i>
            </div>
            <!--  -->
        <label for="lastname" class="col-md-2">Email:  </label>
            <div class="col-md-9">
                <input type="Email" value="<?=$dr_email?>" class="form-control" id="lastname" name='Dr-email'  required placeholder="Enter Dr email if got">
            </div>
             <div class="col-md-1">
                <i class="fa fa-email fa-1x"></i>
            </div>
            <!--  -->
            <div>
            <label for="country" class="col-md-2">
            Service-provider:
            </label>
            <div class="col-md-9">
                <select name="service-provider" id="country" class="form-control">
                    <option>Doctor</option>
                    <option>Nurse</option>
                    <option>Mid-wife</option>
                    <option>Clack</option>
                    <option>Others</option>
                </select>
            </div>            
        </div>
            <div>
            <label for="country" class="col-md-2">
            Infection:
            </label>
            <div class="col-md-9">
                <select  id="country" class="form-control">
                    <option>T.B</option>
                   
                </select>
            </div>            
        </div>

     </div>
            
            <!--  -->
        
      


        
        </div>
        </div>
        </div>
<hr class="hr ">

        <!--  patient part  bio data -->
        <div class="row">
        <div class="col-md-12 col-lg-12">
        <div class="col-md-6">
        <label for="PATIENT'S-DATA" class="col-lg-12 col-md-12 btn btn-default"> PATIENT'S-DATA</label>
        <div>
                <br/>
                <br/>
                <br/>
            <label for="uploadimage" class="col-md-2">
                Upload Image:
            </label>
            <div class="col-md-10">
                <input type="file" disabled name="uploadimage" id="uploadimage">
                <p class="help-block">
                    Allowed formats: jpeg, jpg, gif, png
                </p>
            </div>          
        </div>

        <div>
            <label for="sex" class="col-md-2">
                Gender:
            </label>
            <div class="col-md-10">
                <span class="fa fa-male"></span>
                    <input type="radio" name="patient-sex" class='' id="sex" value="male" checked>
                    Male
                    <span class="fa fa-female"></span>
                    <input type="radio" name="patient-sex" class='' id="Radio1" value="female">
                    Female
            </div>             
        </div>
        <label for="DRname" class="col-md-2">Names:  </label>
            <div class="col-md-9">
                <input type="text" class="form-control" value="<?=$Name?>" pattern="{5,20}" id="lastname" name='patient-name'  required placeholder="Enter Partient's Name">
                <p class="help-block hidden">
                    Max: 20 characters (Alphanumeric letters only )
                </p>
            </div>
             <div class="col-md-1">
                <i class="fa fa-user fa-1x"></i>
            </div>
            <!--  -->
        <label for="contact" class="col-md-2"> Contact:  </label>
            <div class="col-md-9">
                <input type="tel" class="form-control" value="<?=$tell?>"  id="lastname" pattern="^[07]{1}\d{8,9}" name='patient-contact'   placeholder="Enter Doctor's contact">
                <p class="help-block hidden">
                    Min: 10 digits (numbers only) and begin with a (0)
                </p>
            </div>
             <div class="col-md-1">
                <i class="fa fa-phone fa-1x"></i>
            </div>
            </div>
            <!-- <label for="more patient" CLASS='label btn btn-default'> MORE PATIENT FORM </label> -->
        <label for="PATIENT'S-DATA" class="col-lg-6 col-md-12 btn btn-default"> PATIENT'S-DATA</label>
        <div class="col-md-6">
                <br>
            <!--  -->
        <label for="lastname" class="col-md-2">Email:  </label>
            <div class="col-md-9">
                <input type="Email" value="<?=$email?>" class="form-control" id="lastname" name='patient-email' placeholder="Enter Dr email if got">
                <!-- <p class="help-block">
                    Example: ssengendonazil@gmail.com
                </p> -->
            </div>
             <div class="col-md-1">
                <i class="fa fa-lock fa-1x"></i>
            </div>
        <label for="lastname" class="col-md-2">Place of stay:  </label>
            <div class="col-md-9">
                <input type="text" class="form-control" value="<?=$place_of_stay?>" id="lastname" name='victim-place_of_stay'  required placeholder="Enter  place of stay(village)">
            </div>
             <div class="col-md-1">
                <i class="fa fa-home fa-1x"></i>
            </div>
            <h3 class='text-center'>Treatment Supporter <span class="fa fa-info btn "></span></h3>
       
            
        <div>
            <label for="emailaddress" class="col-md-2">
                Contact:
            </label>
            <div class="col-md-9">
                <input type="tell"pattern="^[07]{1}\d{8,9}" class="form-control" value="<?=$sptr_contact?>" id="emailaddress" name='Supportor_tell'  required placeholder="Enter Supporter Contact number">
            </div>
             <div class="col-md-1">
                <i class="fa fa-mobile-phone  fa-1x"></i>
            </div>
        </div>
        <!-- <div> -->
        
        <div> 
            <label for="password" class="col-md-2">
                Village:
            </label>
            <div class="col-md-9">
                <!-- 0751462182 -->
                <input type="text"  value="<?=$sptr_village?>" class="form-control" name='supportor-Village' id="password"  required placeholder="Enter supportor's Village">
                <p class="help-block">
                    Min: 6 characters (Alphanumeric only)
                </p>
            </div>
             <div class="col-md-1">
                <i class="fa fa-lock fa-1x  "></i>
            </div>
        </div>
    </div>
    <div class="row">
<div class="col-md-6">
<label for="emailaddress" class="col-md-2">
                Medication:
            </label>
            <div class="col-md-7">
                <textarea    class="form-control textarea"   name='medication' rows="5"  col=4 placeholder="Enter patient Drag discription"></textarea>
                
            </div>
             <div class="col-md-3">
                <input type="time" class="form-control" value="<?=$drag_time_set?>" name='drag_time_set' id="emailaddress"  required placeholder="Enter patient Drag discription">
                <!-- <input type="date" class="form-control" id="emailaddress"  required placeholder="Enter patient Drag discription"> -->
                 
                <i class="fa fa-clock fa-2x"></i>
            </div>
</div>


    </div>
        </div>
        </div>
        
        <div class="row">
           
            
            <div class="col-md-10 col-lg-offset-5 col-lg-10">
                <button type="submit" class="btn btn-info col-lg-3">
                    Register
                </button>
            </div>
        </div>
    </div>   </div>
    <div CLASS='text-center'><H3>PATIENT DATA TABLE ROW :</H3></div>
    <?php
    
$tbodys_rows='';
    if ($result = $connection->query("SELECT * FROM `patient`  ")) { 
        
        if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
    if ($result->num_rows>0) {
       $i=0;
    
        while ($row = $result->fetch_assoc()) {
            // var_dump($row);
            // $table_v_values[$i]=($row);$i++;
$tbodys_rows.="
<tr>
<td>".$row['pt_ID']."</td>
<td>".$row['Name']."</td>
<td>".$row['gender']."</td>
<td>0".$row['tell']."</td>
<td>T.B</td>
<td>Same</td>
<td>".$row['drag_time_set']."</td>
<td>".$row['facility_name']."</td>
<td>".$row['doctor']."</td>
<td>0".$row['dr_contact']."</td>
<td>".$row['service_provider']."</td>
<td>
<button  type='button' style='border-radius:50%' class='fa fa-pencil  update-patient btn btn-primary' data-actionid='".$row['pt_ID']."'></button>
<button  type='button' style='border-radius:50%' class='fa fa-trash   delete-patient btn btn-danger' data-actionid='".$row['pt_ID']."'></button>
</td>
</tr>
";

            // var_dump($row);
        }
            $result->close();
    }else 
        return false;

    }
    ?>
<table class='table'>
<thead>
    <tr>
    <th>ID</th>
    <th>Patient</th>
    <th>Gender</th>
    <th>Cotact</th>
    <th>Disease</th>
    <th>Medication</th>
    <th>Time</th>
    <th>Facility</th>
    <th>Doctor</th>
    <th>Contact</th>
    <th>svc-provider</th>
    <th>Action</th>

    </tr>
</thead>

<tbody>
    <?=$tbodys_rows?>
</tbody>
</table>


    </div>
    </div>

<?php
    
    # code...
}
elseif ($_REQUEST['register_news']=='Allprovider'){
// echo sha1("0753918842");
    // echo("SELECT * FROM `messages` where  `sender `'%".$_SESSION['valid']."%'");
    if ($result = $connection->query("SELECT * FROM `users` ")) { 
        if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
    if ($result->num_rows>0) {
       $i=0;
    
        while ($row = $result->fetch_assoc()) {
$tbodys_rows.="
<tr>
<td>".$row['username']."</td>
<td>0".$row['tell']."</td>
<td>".$row['post']."</td>
</tr>
";        }
            $result->close();
    }else 
        return false;

    }

// //// all msg



    ?>
<table class='table'>
<thead>
    <tr>
    <th>username</th>
    <th>Tell</th>
    <th>provider</th>
    </tr>
</thead>

<tbody>
    <?=$tbodys_rows?>
</tbody>
</table>


<?php





} 
elseif ($_REQUEST['register_news']=='message'){ 

    // echo("SELECT * FROM `messages` where  `sender `'%".$_SESSION['valid']."%'");
    if ($result = $connection->query("SELECT * FROM `messages` INNER JOIN patient on `patient`.`pt_ID`=`messages`.`PAtientID` 
    where  `sender` like '%".$_SESSION['valid']."%'")) { 
        
        if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
    if ($result->num_rows>0) {
        
       $i=0;
    
        while ($row = $result->fetch_assoc()) {
$tbodys_rows.="
<tr>
<td>".$row['Name']."</td>
<td>".$row['gender']."</td>
<td>".$row['place_of_stay']."</td>
<td>0".$row['tell']."</td>
<td>".$row['notification']."</td>
<td>".date("D-M-Y H:M:s A",$row['time'])."</td>

</tr>
";

        }
            $result->close();
    }else 
        return false;

    }

// //// all msg



    ?>
<table class='table'>
<thead>
    <tr>
    <th>Patient</th>
    <th>sex</th>
    <th>Adress</th>
    <th>contact</th>
    <th>Message</th>
    <th>Time</th>
    </tr>
</thead>

<tbody>
    <?=$tbodys_rows?>
</tbody>
</table>
<?php
}
elseif ($_REQUEST['register_news']=='remaidars-drags'){ 
    // var_dump(1);
    //    echo  "SELECT * FROM `patient` where  `dr_contact`='".$_SESSION['valid']."'";
    if ($result = $connection->query("SELECT * FROM `patient` where  `dr_contact`='".$_SESSION['valid']."'")) { 
        if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
    if ($result->num_rows>0) {
    //  $TotalP=   $connection->query("SELECT COUNT(`pt_ID`)as total_p  FROM `patient`  where  `dr_contact`='".$_SESSION['valid']."'");
       $i=0;
    
        while ($row = $result->fetch_assoc()) {
            $TotalP=1+$i++;
            // var_dump($row);
            // $table_v_values[$i]=($row);$i++;
$tbodys_rows.="
<tr>
<td>".$row['pt_ID']."</td>
<td>".$row['Name']."</td>
<td>".$row['gender']."</td>
<td>0".$row['tell']."</td>
<td>T.B</td>
<td class='text-center'><span class='fa fa-info-circle' title='".$row['medication']."'></span></td>
<td>".$row['drag_time_set']."</td>
<td>".$row['facility_name']."</td>
<td>0".$row['dr_contact']."</td>
<td>".$row['service_provider']."</td>
<td>
<button  type='button' style='border-radius:50%' class='fa fa-x1 fa-infodde hidden  update-patient btn btn-info' data-actionid='".$row['pt_ID']."'></button>
<button  type='button' style='border-radius:50%' class='fa fa-envelope  send_drag_remaider btn btn-primary' data-actionid='".$row['pt_ID']."'></button>
<button  type='button' style='border-radius:50%' class='fa fa-exchange hidden  delete-patient btn btn-danger' data-actionid='".$row['pt_ID']."'></button>
</td>
</tr>
";

            // var_dump($row);
        }
            $result->close();
    }else 
        return false;

    }
?>
Total number of in the system:<?php echo($TotalP)?>
<table class='table'>
<thead>
    <tr>
    <th>ID</th>
    <th>Patient</th>
    <th>Gender</th>
    <th>Contact</th>
    <th>Disease</th>
    <th>Medication</th>
    <th>Time</th>
    <th>Facility</th>
    <th>Dr-Contact</th>
    <th>svc-provider</th>
    <th>Action</th>

    </tr>
</thead>

<tbody>
    <?=$tbodys_rows?>
</tbody>
</table>
<?php

} else {
    var_dump(676567);
   echo "Please  Make a good request";
}



?>
<script>
$(".table").DataTable()
</script>