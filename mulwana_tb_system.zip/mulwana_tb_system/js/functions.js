

$(document).ready(function(){
    dashboardLoader();

})
function systemAction({qnz,functionserver,pageSection,Elmnt}) {
    //    this acts more paffect  on single id values like delete && update
    $(document).on("click",Elmnt,function(){
        $('.alertify-message').css({'color': 'white','font-size': 'medium'})
        staffId=$(this).data("actionid");
        // alert(staffId)
    alertify.confirm(adminQuesioned(qnz)+"<i class='fa fa-question' style='font-size:xx-large;color:darkred'></i>",function (params) {
        if(params){
        ajaxPlain({func:functionserver,page:pageSection,DataID:staffId})
            
            }
        })
    });
    }
function adminQuesioned(params) {
    return(params);
    
}
// dashboard loader
function dashboardLoader(){ 
    $(document).on("click",".page-link",function(e){
        // alert()
        not(e)
        pname=$(this).attr("pname")
       
        $(".loadgif").html(`<img src='assets/pomfile/AjaxLoader.gif'>`).css({ 'z-index': 565,'position': 'fixed','left': '50vw','top': '57vh'});
        // setTimeout(()=>{
            $("#dashboard,.dashboard").load("pages/"+$(this).attr("page"),function(){
                $('#localmotion').html(pname)
            })
            $(".loadgif").html("")
        // },1000);


        });
        return true;
}

function IDtransfer({triger,qnz,redirect}){
    //  this transfer ther data id of stri ng  triggered
$(document).on("click",triger,function () {
    fetchedID=$(this).data('actionid');
    alertify.confirm(adminQuesioned(qnz)+"<i class='fa fa-question'></i>",function (params) {
        if(params){
            alert(redirect)
            $("#dashboard,.dashboard").load("pages/"+redirect+"&&fetchedID="+fetchedID)
        }
})
})

}
 
function adminprograssbar() {
    // $("td").closest(function(){
        $(".t-loader").html('<progress  value="5" id="js-progressbar" class="uk-progress" max="100"></progress>');
        var bar = document.getElementById('js-progressbar');
        animate = setInterval(function () {
          bar.value += 45;
          
          if (bar.value >= bar.max) {
            clearInterval(animate);
          }
        }, 100)
    // })
    
}


 


 

 

function ajaxPlain({form,func,page,DataID}){ 
   
    $.ajax({
            method:"post",
            url: "query/backend.php?data_func=" + func + "&new&DataID=" + DataID,
            data: new FormData($(form)[0]),
            cache:false,
            contentType:false,
            processData:false,
            success:function(params) {
                $(form).show()
                alertify.success(params,"",0);
                setTimeout(() => {
                    loadPage("#dashboard", page);
                }, 2000);

                $("button").off("click");
                
            }
        })}

        function ajax_setTer_id({trigger ,adminQuesioner, functionserver, pageSection}){
            // this will  take id to check db
             $(document).on('click',trigger, function () {
                 dataid=$(this).data('content_id');
                confirm_change('', adminQuesioner, functionserver, pageSection, dataid);
             })
        }

function confirm_change(serialize,adminQuesioner,functionserver,pageSection,dataid='') {
alertify.confirm(adminQuesioned(adminQuesioner) + "<i class='fa fa-question' style='font-size:xx-large;color:darkred'></i>", function (params) {
        if(params){
            ajaxPlain({form:serialize,func:functionserver+"&&new&triggered_id="+serialize+'&dataid='+dataid,page:pageSection})
           
        }
    })


// });
}

function pageTraval(pageSection) {
    setTimeout(() => {
        if(pageSection!=""){
            loadPage("#dashboard",pageSection);
        }else{
            location.reload()
        }

        clearTimeout($(this));
    }, 100);    
}
 



function submition({idattrform,dbfunctionfuery,pageto}){
    $(document).on("submit",idattrform,function(event){
        not(event);
        $(this).hide()
        // alert($($idattrform).serialize())
        ajaxPlain({form:idattrform,func:dbfunctionfuery,page:pageto})
        return true;
    })
}


function loadPage($selector,$pageTo){
   return  $($selector).load("pages/"+$pageTo);

} 
 function not(params){
     return params.preventDefault()
 }
 


