

 submition({idattrform:"#New_patient",dbfunctionfuery:"Add_new_patients_",pageto:"register.php?register_news=patients&users_id=no_yet"});
 systemAction({qnz: "Are you sure to erase this teacher ",functionserver: "Add_new_patients_&&dele_p=delete_patient",pageSection: "register.php?register_news=patients&users_id=no_yet",Elmnt: ".delete-patient"})
 
 IDtransfer({triger: ".update-patient",qnz: "Can i Continue with The process",redirect: "register.php?register_news=patients&users_id=no_yet"
});
$(document).on("click",".send_drag_remaider",function(){
 patient_id=$(this).data('actionid');
    $(".universalId-form").attr("id","send_drag_remaider_confirmation")
    $("#universalId").attr("value",patient_id)
    $(".pomscroll2").show()
    // alert(patient_id)
    $(".pomscroll2").removeClass("hidden")
$(".modal-body").show().html(`<label for="emailaddress" class="col-md-2">
Message:
</label> 
<div class="col-md-12">
<textarea    class="form-control textarea" style='resize:none' required  name='notification' rows="5"  col=4 placeholder="Enter patient Drag discription"></textarea>

</div>
<div class="col-md-12 text-center">
<button type='submit' class='btn btn-primary '> Remaind</button>
</div>
</div>`)
})
 $(document).on("click",'.close',function(){
    $(".pomscroll2").hide()

 })

submition({idattrform:"#send_drag_remaider_confirmation",dbfunctionfuery:"remaid_patient",pageto:"register.php?register_news=patients&users_id=no_yet"});
IDtransfer({triger: ".send_drag_remaider_confirmation",qnz: "Send A remaider to A Patientt",redirect: "register.php?register_news=patients&users_id=no_yet"
});
















