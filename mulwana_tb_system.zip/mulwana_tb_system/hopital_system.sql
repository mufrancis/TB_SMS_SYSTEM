-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 27, 2006 at 10:51 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hopital_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `mgs_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PAtientID` int(11) DEFAULT NULL,
  `notification` text,
  `sender` varchar(88) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`mgs_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`mgs_ID`, `PAtientID`, `notification`, `sender`, `time`) VALUES
(12, 18, ' for mtn waking\r\n', 'Dr:nei \n 751462182\r\n    ', 1574952253),
(13, 20, 'hello', 'Dr:brother ronnie \n 783400228\r\n    ', 1156715626),
(11, 18, 'warhy\r\n', 'Dr:nei \n 751462182\r\n    ', 1574952174),
(10, 18, 'heyyy gwe', 'Dr:nei \n 751462182\r\n    ', 1574951368),
(14, 20, 'hello', 'Dr:brother ronnie \n 783400228\r\n    ', 1156715695),
(15, 20, 'hello', 'Dr:brother ronnie \n 783400228\r\n    ', 1156715784);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `pt_ID` int(11) NOT NULL AUTO_INCREMENT,
  `profile` varchar(50) DEFAULT NULL,
  `gender` text,
  `tell` int(45) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `place_of_stay` varchar(40) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `sptr_village` varchar(90) DEFAULT NULL,
  `service_provider` varchar(78) DEFAULT NULL,
  `doctor` varchar(123) DEFAULT NULL,
  `dr_gender` varchar(90) DEFAULT NULL,
  `dr_contact` int(90) DEFAULT NULL,
  `dr_email` varchar(90) DEFAULT NULL,
  `facility_name` varchar(140) DEFAULT NULL,
  `sptr_contact` int(61) DEFAULT NULL,
  `medication` text,
  `drag_time_set` time DEFAULT NULL,
  PRIMARY KEY (`pt_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pt_ID`, `profile`, `gender`, `tell`, `Name`, `place_of_stay`, `email`, `sptr_village`, `service_provider`, `doctor`, `dr_gender`, `dr_contact`, `dr_email`, `facility_name`, `sptr_contact`, `medication`, `drag_time_set`) VALUES
(18, NULL, 'male', 783400228, 'nazil', 'kak', 'sse2@gmail.com', '783400228', 'Nurse', 'nei', 'male', 751462182, 'ssen@gmail.com', 'hhhhhhkk', 783400228, 'basdnada', '01:00:00'),
(17, NULL, 'male', 751462182, 'nazil2', 'kak', 'sse@gmail.com', '751462182', 'Nurse', 'nei', 'male', 753918842, 'ssen@gmail.com', 'hhhhhhkk', 751462182, 'basdnada', '01:00:00'),
(19, NULL, 'male', 753918842, 'john', 'gangu', 'sse2@gmail.com', 'massaja', 'Doctor', 'levinsons', 'male', 751462182, 'levinsons@gmail.com', 'st anthony nation hospitals', 783400228, '2 pills', '01:00:00'),
(20, NULL, 'male', 783400228, 'petter', 'gangu', 'ssengendo@gmail.com', 'massaja', 'Doctor', 'brother ronnie', 'male', 783400228, 'brotherronnie@gmail.com', 'st jonath hospital nsabya', 783400228, '15 tins of dysons', '23:00:00'),
(21, NULL, 'male', 753918842, 'petters2', 'gangu', 'sse2@gmail.com', 'massaja', 'Doctor', 'brotherronnie', 'male', 783400228, 'brotherronnie@gmail.com', 'st anthony nation hospitals', 783400228, '5 tps of ', '01:00:00'),
(22, NULL, 'male', 751462182, 'john2', 'gangu', 'sse2@gmail.com', 'massaja', 'Doctor', 'levinsons', 'male', 783400228, 'levinsons@gmail.com', 'st anthony nation hospitals', 783400228, '5 tps of ', '01:00:00'),
(23, NULL, 'male', 751462182, 'john3', 'gangu', 'sse2@gmail.com', 'massaja', 'Doctor', 'levinsons', 'male', 751462182, 'levinsons@gmail.com', 'st anthony nation hospitals', 783400228, '5 tps of ', '01:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `supporters`
--

DROP TABLE IF EXISTS `supporters`;
CREATE TABLE IF NOT EXISTS `supporters` (
  `sptr_id` int(11) NOT NULL AUTO_INCREMENT,
  `supportor_Village` varchar(50) DEFAULT NULL,
  `sptr_gender` text,
  `tell` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `contact` int(11) DEFAULT NULL,
  `place_of_stay` varchar(40) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`sptr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` text,
  `tell` int(23) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `f_name` varchar(40) DEFAULT NULL,
  `l_name` varchar(40) DEFAULT NULL,
  `system_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `username`, `password`, `tell`, `post`, `f_name`, `l_name`, `system_id`) VALUES
(14, 'admin@gmail.com', 'd726cd5ccbd714b958014cff27c128ccc6d71a44', 753918842, 'admin', NULL, NULL, NULL),
(13, 'petter@gmail.com', '544defb124b7ad03e14075009b8d9c298af74321', 753475676, 'Nurse', NULL, NULL, NULL),
(12, 'john@gmail.com', 'dce8f6adfe63773e40d0bb854ca7af7cbac2f104', 751462189, 'dovtor', NULL, NULL, NULL),
(15, 'levinsons@gmail.com', '544defb124b7ad03e14075009b8d9c298af74321', 751462182, 'Doctor', NULL, NULL, NULL),
(16, 'brotherronnie@gmail.com', '9aec628e8f67e713bf3298a4578e579dbfd465e7', 783400228, 'Doctor', NULL, NULL, NULL),
(17, 'brotherronnie@gmail.com', '9aec628e8f67e713bf3298a4578e579dbfd465e7', 783400228, 'Doctor', NULL, NULL, NULL),
(18, 'levinsons@gmail.com', '9aec628e8f67e713bf3298a4578e579dbfd465e7', 751462182, 'Doctor', NULL, NULL, NULL),
(19, 'levinsons@gmail.com', '75ee68fa02ac192c1958e5062812746bee8f66c0', 751462182, 'Doctor', NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
