<?php  session_start();
ob_start();
include_once('../connection/connect.php');
$connection=  $link_connector; 
// getway pannel api function








if($_REQUEST['data_func']=='Add_new_patients_'){
  
      if(isset($_REQUEST['dele_p'])){
  $data_id=$_REQUEST['DataID'];
  $prepared= $connection->prepare("DELETE FROM `patient` WHERE `pt_ID`=?");
  $prepared==FALSE?die("delete secured prepared  $table".mysqli_error($con)):"";
    
    // if($data != ''){
      $result=$prepared->bind_param('s',$data_id);
      $result==FALSE?die("delete bind $table ".(mysqli_error($con))):"";
    // }
     
      }
      else{
        $facility=$_REQUEST['hospital-name'];
        $DRSEX=$_REQUEST['dr_sex'];
        $Dr_names=$_REQUEST['Dr-name'];
        $Dr_contact=$_REQUEST['Dr-contact'];
        $Dr_email=$_REQUEST['Dr-email'];
        $Dr_service_provider=$_REQUEST['service-provider'];
        //  next patient 
        $patient_sex=$_REQUEST['patient-sex'];
        $patient_name=$_REQUEST['patient-name'];
        $drag_time_set=$_REQUEST['drag_time_set'];
        // $patient_name=$_REQUEST['patient-name'];
        $patient_contact=$_REQUEST['patient-contact'];
        $medication=$_REQUEST['medication'];
        // $patient_contact=$_REQUEST['patient-contact'];
        // $patient_email=$_REQUEST['patient-email'];
        $patient_email=$_REQUEST['patient-email'];
        $patient_victim_place_of_stay=$_REQUEST['victim-place_of_stay'];
        //  next supoter
        $patient_Supportor_tell=$_REQUEST['Supportor_tell'];
        $patient_supportor_Village=$_REQUEST['supportor-Village'];
        if(isset($_REQUEST['Patient_id'])){
      $prepared= $connection->prepare("UPDATE  `patient` SET 
        `gender`=?, `tell`=?, `Name`=?, `place_of_stay`=?,
       `email`=?, `sptr_village`=?,`sptr_contact`=?,`service_provider`=?, `doctor`=?,
        `dr_gender`=?, `dr_contact`=?, `dr_email`=?, `facility_name`=?,`drag_time_set`=?,`medication`=?  where `pt_ID`=".$_REQUEST['Patient_id']."
      -- VALUES ( ?, ?, ?, ?, ?, ?, ? ,?,?,?,?,?,?,?) "
      );
      
$result=$prepared->bind_param("sssssssssssssss",$patient_sex ,$patient_contact,$patient_name,$patient_victim_place_of_stay,
$patient_email,$patient_supportor_Village,$patient_Supportor_tell,$Dr_service_provider,$Dr_names,
$DRSEX,$Dr_contact,$Dr_email,$facility,$drag_time_set,$medication
);
      }else{
        // var_dump($Dr_email);
      $prepared= $connection->prepare("INSERT INTO `patient` 
      (  `gender`, `tell`, `Name`, `place_of_stay`,
       `email`, `sptr_village`,`sptr_contact`,`service_provider`, `doctor`,
        `dr_gender`, `dr_contact`, `dr_email`, `facility_name`,`drag_time_set`,`medication`) 
      VALUES ( ?, ?, ?, ?, ?, ?, ? ,?,?,?,?,?,?,?,?) "); 
      

$result=$prepared->bind_param("sssssssssssssss",$patient_sex ,$patient_contact,$patient_name,$patient_victim_place_of_stay,
$patient_email,$patient_supportor_Village,$patient_Supportor_tell,$Dr_service_provider,$Dr_names,
$DRSEX,$Dr_contact,$Dr_email,$facility,$drag_time_set,$medication
);
if($result==false)
die("Secured results");
$result=$prepared->execute();    
if($result==false){
    die("Secured result prepared".mysqli_error($connection));
}
// echo  $fedSQL ="patient Joined TB medication successfully";
$prepared->close();


      $prepared= $connection->prepare("INSERT INTO `users` 
      ( `username`, `password`,`post`,`tell`) 
      VALUES ( ?, ?, ?,?) "); 
$pwd=sha1($Dr_contact);
      $result=$prepared->bind_param("ssss",$Dr_email,$pwd,$Dr_service_provider,$Dr_contact)
;}

}
  if($result==false)
    die("Secured results");
    $result=$prepared->execute();    
    if($result==false){
        die("Secured result prepared".mysqli_error($connection));
    }
    echo  $fedSQL=(isset($_REQUEST['Patient_id']))?"Patient successfully updated":isset($data_id)?"patient Joined TB medication successfully":"Record deleted" ;
    $prepared->close();
// } end of new paient
}


// 
if($_REQUEST['data_func']=='remaid_patient'){
  $patient_id=$_REQUEST['universalId'];
  $notification=$_REQUEST['notification'];
  $sender=($_SESSION['valid']);
  $time=time();
  $prepared= $connection->prepare("INSERT INTO `messages` 
  ( `PAtientID`, `notification`,`sender`,`time`) 
  VALUES ( ?, ?, ?,?) "); 
// $pwd=sha1($Dr_contact);
  
// send messages to patient
if ($result = $connection->query("SELECT * FROM `patient` where `pt_ID`='$patient_id' ")) { 
        
  if($result==false) die('Select Query Error In MySQL: ' . error_check($mysqli->error) );
if ($result->num_rows>0) {
 $i=0;

  while ($row = $result->fetch_assoc()) {
    extract($row);
    $number =isset($tell)?"%2B256".$tell:"%2B256".$sptr_contact;
    $reference =isset($tell)?"":"please save a life and tell";
    $sender ="Dr:$doctor \n $dr_contact
    $reference";
    
  }
  }
  }
  // var_dump($number);
  // $number="%2B256751462182";

$username ="ssengendonazil";
$password ="Mavinnazil";

// to sender
// SendSMS($username,$password,$number,$sender,"$message Message delivared successfuly");
// to patient
if (SendSMS($username,$password,$sender,$number,$notification,$patient_id,$notification,$time,$prepared)){
// var_dump("message sent");
}
; 
}else{
   echo "please u not allowed in";
}
function SendSMS($username,$password,$sender,$number,$message,$patient_id,$notification,$time,$prepared) {
  // if(@$intnt=fsockopen("www.egosms.co/api/v1/plain/?",80)==true){ //var_dump(1);



    // 
  if(@$intnt=fsockopen("www.egosms.co/api/v1/plain/?",80)){ //var_dump(1);
    echo"Please check your internet connection and resubmit \n <i class='text-danger'>Message failed to delivary </i>";
  }else{//var_dump("ok");
    $url = "www.egosms.co/api/v1/plain/?";
    $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]";
    $parameters = str_replace("[message]", urlencode($message), $parameters);
    $parameters = str_replace("[sender]", urlencode($sender),$parameters);
    $parameters = str_replace("[number]", urlencode($number),$parameters);
    $parameters = str_replace("[username]", urlencode($username),$parameters);
    $parameters = str_replace("[password]", urlencode($password),$parameters);

    $live_url="http://".$url.$parameters;
    $parse_url=file($live_url);
    $response = $parse_url[0];
    $result=$prepared->bind_param("ssss",$patient_id,$notification,$sender,$time);
    if($result==false)
    die("Secured results");
    $result=$prepared->execute();    
    if($result==false){
        die("Secured result prepared");
    }
    $prepared->close();
    echo "Message to delivared";

  }
  }
  // unction SendSMS($username,$password,$sender,$number,$message) {
  //   //  remember tht your number should have an country code 256
  //   // and start with %2B256*********
  //   var_dump("number=$number&message=$message&username=$username&password=$password&sender=$sender");
  //   if(!$intnt=@fsockopen("www.egosms.co/api/v1/plain/?",80)){
  //   //   echo"Please check your internet connection \n <i class='text-danger'>Message failed to delivary </i>";
  //   }else{
  //     // if($number[0]=='0'){
  //     //   $str_rpl=str_replace($number[0],"%2B256",$number);
  //     // }else {
  //     //   $str_rpl=str_replace("256","%2B256",$number);
  //     // }
  //   $url = "www.egosms.co/api/v1/plain/?";
  //   $live_url="http://".$url.urlencode("number=$number&message=$message&username=$username&password=$password&sender=$sender");
  //   $parse_url=file($live_url);
  //   $response = $parse_url[0];
  //   // var_dump($response);
  //   return $response;
  //   }
  //   }

 ;
?>