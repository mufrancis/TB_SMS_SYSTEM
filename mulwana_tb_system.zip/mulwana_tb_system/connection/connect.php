<?php

 $link_connector=mysqli_connect('localhost', 'root', '', "hopital_system")

?>